# MLM-Website-Using-PHP-Binary-Plan-Version-2.0-Final
This is the final code of the MLM Website Using PHP - Binary Plan

<h4>Instruction for Installation</h4>
<ol>
  <li>Download all.zip folder</li>
  <li>Upload it to your server</li>
  <li>Unzip all.zip</li>
  <li>You will get SQL file with the name of <b>mlm.sql</b></li>
  <li>Create Database in your server and Import mlm.sql file</li>
  <li>Now Configure connect.php file that is inside <b>/php-includes/connect.php</b> folder. Change the databsae name, host, username, and password according to your server details.</li>
  <li>Also do the same database configure inside the <b>/admin/php-includes/connect.php</b>
  <li>All done. It is ready to use. You can acces your admin area by the link yourdomin.com/admin </li>
  <li>Admin's username and password is already stored in the admin table in the Database</li>
</ol>

<br><br>
Hope the above instruction will help you. Anyway if you get any problem then you can email or whatsapp me from Monday to Friday.
<br>Email - santoshdevnath15@gmail.com
<br>Mobile - +91 8077775266

<br><br>

Here is my website - https://tutorialvilla.com/

<br><br>

<h2>You can also Hire me for your complete MLM Projects.</h2>
<h3>we never compromise on quality.</h3>

<br><br>
<h2>Join X Developers on Discord </h2> https://discord.gg/y9estKq
<br>You can get all types of help regarding devlopement or you can be a hero by doing it for other's :) 

<br>

<h2>Project Videos on YouTube</h2>


Here is the Youtube project link for the MLM Binary Plan 1X2 - https://www.youtube.com/watch?v=0fBScrC0cKU&list=PLnq9yHs8s_hm6LEwIJ4qlV53U6Fo--YZh

<br><br>

If you want to create website for MLM Matrix Plan 1x3 using PHP and MySQL then Click here - https://www.youtube.com/watch?v=4UCaSZFieC0&list=PLnq9yHs8s_hnX7mdPneeuVSrHGVMdrCXO
